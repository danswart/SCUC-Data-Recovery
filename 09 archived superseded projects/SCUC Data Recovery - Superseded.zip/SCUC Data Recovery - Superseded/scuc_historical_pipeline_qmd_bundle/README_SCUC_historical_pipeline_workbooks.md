# SCUC historical-pipeline workbooks

Use the workbooks in this order:


1. `00_scuc_master_discovery.qmd`     DONE!

   - Run once from the R working-directory home base.
   - Finds SCUC-named files and folders recursively at unlimited depth.
   - Produces candidate project roots and special reports for root-level strays.



**Step 1 - Actions**

   1. DONE!! - Inspect `root_level_scuc_strays.csv` first (in the '/R Working Directory/SCUC-discovery_review' folder).

   2. DONE!! - Inspect `/R Working Directory/scuc_files_outside_scuc_folders` (in the '/R Working Directory/SCUC-discovery_review' folder); their locations may reveal forgotten projects.

   3. DONE!! -  Edit `candidate_project_roots.csv` (in the '/R Working 
      Directory/SCUC-discovery_review' folder) and mark genuine 
      project roots `yes`. 
      
         - Do not treat nested SCUC directories as separate projects
      unless they truly have an independent data pipeline.
  

2. `01_scuc_historical_pipeline_file_triage.qmd`
   - Run once for each confirmed SCUC project root.
   - Inventories the complete project, not only filenames containing SCUC.
   - Creates the human review CSV, archive plan, safe previews, and dry-run copy plan.

3. `02_scuc_portfolio_lineage_consolidation.qmd`
   - Run after the individual project reviews.
   - Combines approved milestones and reports unresolved projects and overlap.

All workbooks are conservative. They do not automatically delete source files.

## Downloading

The accompanying ZIP contains the original plain-text `.qmd` files. Download and
unzip it, then open the QMD files directly in RStudio or another text editor.
