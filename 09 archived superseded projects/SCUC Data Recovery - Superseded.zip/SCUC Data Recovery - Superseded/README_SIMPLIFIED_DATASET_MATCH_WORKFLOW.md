# Simplified SCUC dataset-match workflow

The recovery project now has two purpose-specific workbooks:

1. `00_scuc_dataset_match_audit.qmd` searches `/Users/D/R Working Directory`, screens for plausible SCUC Snapshot tables, compares their normalized contents with all canonical and pre-canonical references, and writes reports. It is read-only with respect to source data.
2. `01_scuc_stage_classified_copies.qmd` reads the generated manifest and prepares a dry-run copy plan. Set `dry_run <- FALSE` only after reviewing the manifest.

The proposed staging folders are:

- `06 canonical data set matches`
- `07 pre-canonical set matches`
- `08 datasets prior to pre-canonical set matches`

Copies retain their path relative to `/Users/D/R Working Directory`, so identically named files from different projects cannot overwrite one another and their provenance remains visible.

No workbook deletes, moves, or renames originals.
